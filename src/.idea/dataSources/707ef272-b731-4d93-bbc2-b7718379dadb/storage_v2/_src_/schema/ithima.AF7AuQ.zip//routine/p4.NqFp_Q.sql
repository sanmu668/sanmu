create
    definer = root@localhost procedure p4(IN score int, OUT result varchar(10))
begin
    if score >= 85 then
        set result := '优秀';
    elseif score>=60 and score<85 then
        set result := '及格';
    else
        set result := '不及格';
    end if;

end;

