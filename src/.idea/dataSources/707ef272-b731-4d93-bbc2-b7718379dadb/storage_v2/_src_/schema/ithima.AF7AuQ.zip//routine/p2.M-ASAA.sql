create
    definer = root@localhost procedure p2()
begin
    declare stu_count int default 0;

    -- 赋值

    select count(*) into stu_count from users limit 1;
    select stu_count;
end;

