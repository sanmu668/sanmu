create
    definer = root@localhost procedure p6(IN mount int)
begin
    declare season varchar(10);
    case
        when mount>=1 and mount<=3 then
            set season := '第一季度';
        when mount>=4 and mount<=6 then
            set season := '第二季度';
        when mount>=7 and mount<=9 then
            set season := '第三季度';
        when mount>=10 and mount<=12 then
            set season := '第四季度';
        else  set season := '非法参数';
    end case ;
    select concat('您输入的月份为：',mount,'所属季度为：',season);
end;

