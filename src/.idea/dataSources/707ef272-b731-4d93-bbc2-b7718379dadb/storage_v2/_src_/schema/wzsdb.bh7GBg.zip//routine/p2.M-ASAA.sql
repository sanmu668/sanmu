create
    definer = root@localhost procedure p2()
begin
    declare age int;
    declare name varchar(20);

    -- 赋值
    -- set age = 18;
    select sname into name from wzs_s limit 1;
end;

