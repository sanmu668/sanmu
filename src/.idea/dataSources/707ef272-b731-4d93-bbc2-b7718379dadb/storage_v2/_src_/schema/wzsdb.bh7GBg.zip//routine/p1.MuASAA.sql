create
    definer = root@localhost procedure p1()
begin
    select sname,department from wzs_s;
end;

