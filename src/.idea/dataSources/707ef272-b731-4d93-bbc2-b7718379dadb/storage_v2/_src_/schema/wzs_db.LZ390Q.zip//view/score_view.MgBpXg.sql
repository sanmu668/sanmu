create definer = root@localhost view score_view as
select `s`.`sid` AS `sid`, `s`.`sname` AS `sname`, `sc`.`cid` AS `cid`, `c`.`cname` AS `cname`, `sc`.`score` AS `score`
from ((`wzs_db`.`wzs_s` `s` join `wzs_db`.`wzs_sc` `sc` on ((`s`.`sid` = `sc`.`sid`))) join `wzs_db`.`wzs_c` `c`
      on ((`sc`.`cid` = `c`.`cid`)));

-- comment on column score_view.sid not supported: 学号

-- comment on column score_view.sname not supported: 姓名

-- comment on column score_view.cid not supported: 课程号

-- comment on column score_view.cname not supported: 课程名

-- comment on column score_view.score not supported: 成绩

